/* nav.js — ortak navigasyon ve footer enjeksiyonu */

const NAV_HTML = `
<nav class="navbar" id="navbar">
  <div class="navbar__inner">
    <a href="index.html" class="navbar__brand">
      <div class="navbar__logo-mark">H</div>
      <div class="navbar__brand-text">
        <span class="navbar__brand-title">Holistik Düşünce</span>
        <span class="navbar__brand-sub">TÜBİTAK 1001 Projesi</span>
      </div>
    </a>
    <ul class="navbar__links">
      <li><a href="index.html">Ana Sayfa</a></li>
      <li><a href="holizm-nedir.html">Holizm Nedir?</a></li>
      <li><a href="literatur.html">Literatür</a></li>
      <li><a href="proje.html">1001 Projesi</a></li>
      <li><a href="yayinlar.html">Yayınlar</a></li>
      <li><a href="ekip.html">Ekip</a></li>
    </ul>
    <button class="navbar__hamburger" id="menuBtn" aria-label="Menü">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="navbar__mobile" id="mobileMenu">
    <a href="index.html">Ana Sayfa</a>
    <a href="holizm-nedir.html">Holizm Nedir?</a>
    <a href="literatur.html">Literatür</a>
    <a href="proje.html">1001 Projesi</a>
    <a href="yayinlar.html">Yayınlar</a>
    <a href="ekip.html">Ekip</a>
  </div>
</nav>`;

const FOOTER_HTML = `
<footer>
  <div class="container">
    <div class="footer__inner">
      <div class="footer__brand">
        <h3>Holistik Düşünce Araştırma Projesi</h3>
        <p>TÜBİTAK 1001 destekli bu proje, holistik düşünce stilinin kavramsal, psikometrik ve sosyal boyutlarını araştırmaktadır.</p>
        <span class="badge badge--gold">Proje No: 221K040</span>
      </div>
      <div class="footer__col">
        <h4>Sayfalar</h4>
        <ul class="footer__links">
          <li><a href="index.html">Ana Sayfa</a></li>
          <li><a href="holizm-nedir.html">Holizm Nedir?</a></li>
          <li><a href="literatur.html">Geçmiş Literatür</a></li>
          <li><a href="proje.html">1001 Projesi</a></li>
          <li><a href="yayinlar.html">Yayınlar</a></li>
          <li><a href="ekip.html">Ekip</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Kurumlar</h4>
        <ul class="footer__links">
          <li><a href="https://www.kadirhas.edu.tr" target="_blank">Kadir Has Üniversitesi</a></li>
          <li><a href="https://www.tubitak.gov.tr" target="_blank">TÜBİTAK</a></li>
          <li><a href="https://osf.io" target="_blank">OSF Açık Veri</a></li>
        </ul>
      </div>
    </div>
    <div class="footer__bottom">
      <span>© 2024 Holistik Düşünce Araştırma Projesi — Kadir Has Üniversitesi</span>
      <div class="footer__bottom-logo">TÜBİTAK 1001 · 221K040</div>
    </div>
  </div>
</footer>`;

document.addEventListener('DOMContentLoaded', () => {
  // Nav & footer enjekte et
  const navPlaceholder = document.getElementById('nav-placeholder');
  const footerPlaceholder = document.getElementById('footer-placeholder');
  if (navPlaceholder)    navPlaceholder.outerHTML = NAV_HTML;
  if (footerPlaceholder) footerPlaceholder.outerHTML = FOOTER_HTML;

  // Navbar scroll efekti
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 50);
    });
  }

  // Hamburger menü
  const menuBtn = document.getElementById('menuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
    });
  }

  // Aktif menü öğesi
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar__links a, .navbar__mobile a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });

  // Accordion
  document.querySelectorAll('.accordion__toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const body = btn.nextElementSibling;
      const isOpen = btn.classList.contains('open');
      // Hepsini kapat
      document.querySelectorAll('.accordion__toggle').forEach(b => {
        b.classList.remove('open');
        b.nextElementSibling.classList.remove('open');
      });
      if (!isOpen) {
        btn.classList.add('open');
        body.classList.add('open');
      }
    });
  });

  // Sekmeler (Tabs)
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      const container = btn.closest('.tabs-container') || document;
      container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const panel = container.querySelector(`#${target}`);
      if (panel) panel.classList.add('active');
    });
  });

  // Smooth scroll iç bağlantılar
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Sayı animasyonu (istatistikler için)
  const animateNumbers = () => {
    document.querySelectorAll('[data-count]').forEach(el => {
      const target = parseInt(el.dataset.count);
      const duration = 1800;
      const start = performance.now();
      const update = (time) => {
        const progress = Math.min((time - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.floor(eased * target).toLocaleString('tr-TR');
        if (progress < 1) requestAnimationFrame(update);
        else el.textContent = target.toLocaleString('tr-TR');
      };
      requestAnimationFrame(update);
    });
  };

  // IntersectionObserver ile tetikle
  const statsSection = document.querySelector('.stats-section');
  if (statsSection) {
    const obs = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) { animateNumbers(); obs.disconnect(); }
    }, { threshold: 0.3 });
    obs.observe(statsSection);
  }
});
